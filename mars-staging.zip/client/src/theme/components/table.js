const Table = {
  defaultProps: {
    colorScheme: "teal",
  },
};

export default Table;
