const Button = {
  defaultProps: {
    colorScheme: "teal",
  },
};

export default Button;
