const Tabs = {
  defaultProps: {
    colorScheme: "teal",
  },
};

export default Tabs;
