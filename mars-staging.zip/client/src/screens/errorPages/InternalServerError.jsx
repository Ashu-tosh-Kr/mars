const InternalServerError = () => {
  return <div>500 internal server error</div>;
};

export default InternalServerError;
