const companies = [
  {
    name: "Sony",
    postCode: "987868",
    officeAddress: "Address line 1",
    note: "Awesome company",
  },
  {
    name: "Yahoo",
    postCode: "987868",
    officeAddress: "Address line 1",
    note: "Awesome company",
  },
  {
    name: "Line",
    postCode: "987868",
    officeAddress: "Address line 1",
    note: "Awesome company",
  },
];
export default companies;
