export const clients = [
  {
    name: "Steven Spielberg",
    title: "Director",
    clientTeam: "Movie Team",
    email: "abc@fsfd.com",
    phone: "97837834783",
    note: "Amazing director",
  },
  {
    name: "Christopher Nola",
    title: "Director",
    clientTeam: "Movie Team",
    email: "abc@fsfd.com",
    phone: "97837834783",
    note: "Amazing director",
  },
  {
    name: "Quentine Tarantino",
    title: "Director",
    clientTeam: "Movie Team",
    email: "abc@fsfd.com",
    phone: "97837834783",
    note: "Amazing director",
  },
];
export default clients;
