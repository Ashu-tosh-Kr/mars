const companies = [
  {
    name: "ソニーキャニオン",
    postCode: "1103344",
    officeAddress: "東京都 杉並区 123 ソニービル",
    note: "駐車場代は出ない",
  },
  {
    name: "ジフTV",
    postCode: "2002222",
    officeAddress: "富士県 高砂町 森田区",
    note: "特になし",
  },
  {
    name: "MHK",
    postCode: "3334455",
    officeAddress: "山川県 高波市 吉村区",
    note: "タトゥーは隠すこと",
  },
  {
    name: "西海テレビ",
    postCode: "4833410",
    officeAddress: "名古屋市 中区 栄123",
    note: "上田さんが担当",
  },
  {
    name: "大京テレビ",
    postCode: "4119320",
    officeAddress: "大阪市 堺市999",
    note: "必ず社長に相談してから受注すること",
  },
];
export default companies;
