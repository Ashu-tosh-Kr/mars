const clients = [
  {
    name: "古立善之",
    title: "ディレクター",
    clientTeam: "映像企画部",
    email: "tat@example.com",
    phone: "09073829981",
    note: "交通費は出ない, 請求書は月末に送ること",
  },
  {
    name: "土屋敏男",
    title: "ディレクター",
    clientTeam: "映像企画部",
    email: "tat@example.com",
    phone: " 09073829981",
    note: "優しい人です",
  },
  {
    name: "友寄隆英",
    title: "部長",
    clientTeam: "スポーツ映像部",
    email: "tomo@example.com",
    phone: " 09073829981",
    note: "特になし",
  },
  {
    name: "加地倫三",
    title: "ADD",
    clientTeam: "映像企画部",
    email: "kaji@example.com",
    phone: " 09073829981",
    note: "金曜は連絡が取れない",
  },
  {
    name: "舟橋政宏",
    title: "企画室長",
    clientTeam: "企画室",
    email: "funahashi@example.com",
    phone: " 09073829981",
    note: "厳しいので失礼のないように",
  },
];

export default clients;
